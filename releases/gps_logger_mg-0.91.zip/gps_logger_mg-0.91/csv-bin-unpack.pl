#!/usr/bin/perl

#
# Copyright (C) 2007 gps_logger_mg@tanundra.com. All rights reserved.
# Licensed for non-commercial distribution and use.
#

use strict;
use warnings;

use POSIX qw (ceil floor);
use Getopt::Long;

################################################################################

sub bintodec {
	return unpack ("N", pack ("B32", substr ("0" x 32 . shift, -32)));
}

sub secstohhmmss {
	my ($ss) = @_;
	my ($hh) = POSIX::floor ($ss / (60 * 60)); $ss -= $hh * (60 * 60);
	my ($mm) = POSIX::floor ($ss / 60); $ss -= $mm * 60;
	return sprintf ("%02d%02d%02d", $hh, $mm, $ss);
}

################################################################################

my $cfg_elements = "";
my $cfg_debug = "";

printf STDERR "gps_logger_mg v0.91 (\"$^O\"): csv unpack tool.\n";
printf STDERR "copyright (c) 2007 gps_logger_mg@tanundra.com. all rights reserved.\n";

my $result = GetOptions ("elements=s" => \$cfg_elements,
						 "version" => sub { exit; },
						 "help" => sub { print STDERR "usage: $0 [-v] [-h] [-d] -e <lat,lon,alt,tim>\n"; exit; },
						 "debug" => \$cfg_debug);

print STDERR "elements = $cfg_elements\n" if ($cfg_debug);
print STDERR "debug = $cfg_debug\n" if ($cfg_debug);

$cfg_elements || die ("fatal: a comma separated list of elements must be defined\n");

my (%cfg_defined) = (
	"lat" => { size => (1 + 7 + 20), func => sub { 
					my ($v) = @_;
					my ($r) = (substr ($v, 0, 1) eq "1" ? '-' : '') .
	  							bintodec (substr ($v, 1, 7)) . "." .
	 							sprintf ("%06d", bintodec (substr ($v, 1 + 7, 20)));
					return (substr ($v, 1 + 7 + 20), $r);
			} },
	"lon" => { size => (1 + 8 + 20), func => sub { 
					my ($v) = @_;
					my ($r) = (substr ($v, 0, 1) eq "1" ? '-' : '') .
	  							bintodec (substr ($v, 1, 8)) . "." .
	 							sprintf ("%06d", bintodec (substr ($v, 1 + 8, 20)));
					return (substr ($v, 1 + 8 + 20), $r);
			} },
	"alt" => { size => (1 + 15), func => sub {
					my ($v) = @_;
					my ($r) = (substr ($v, 0, 1) eq "1" ? '-' : '') .
								bintodec (substr ($v, 1, 15));
					return (substr ($v, 1 + 15), $r);
			} },
	"tim" => { size => (17), func => sub {
					my ($v) = @_;
					my ($r) = secstohhmmss (bintodec (substr ($v, 0, 17)));
					return (substr ($v, 17), $r);
			} }
);

################################################################################

my @rec_elements;
my $rec_numbits = 0;
for my $e (split (",", $cfg_elements)) {
	exists ($cfg_defined{$e}) || die ("fatal: element <$e> is not valid\n");
	$rec_numbits += $cfg_defined{$e}{'size'};
	push @rec_elements, $cfg_defined{$e}{'func'};
}
my $rec_numbyts = POSIX::ceil ($rec_numbits / 8);
print STDERR "bits = $rec_numbits (byts = $rec_numbyts)\n" if ($cfg_debug);

################################################################################

binmode (STDIN, ":raw") || die ("fatal: cannot enable binmode for STDIN\n");
my $rec_number = 0;
my $rec_content;
while (read (STDIN, $rec_content, $rec_numbyts) == $rec_numbyts) {
	$rec_content = unpack ("B*", $rec_content);
	my (@rec_results, $rec_current);
	for my $rec_decode (@rec_elements) {
		($rec_content, $rec_current) = &$rec_decode ($rec_content);
		push @rec_results, $rec_current;
	}
	print STDOUT join (',', @rec_results), "\n";
	$rec_number++;
}
print STDERR "recs = $rec_number\n" if ($cfg_debug);

################################################################################

exit 0;
