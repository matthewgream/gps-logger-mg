
/* ----------------------------------------------------------------------------------------------------*/
/*
	mod_packlzari.c: gps logger module for LZARI based packer.
	copyright (c) 2007 gps_logger_mg@tanundra.com. all rights reserved.
	refer to the associated LICENSE file for licensing terms/conditions.
 */
/* ----------------------------------------------------------------------------------------------------*/

#define VERSION "0.94"
#define COPYRIGHT "copyright (c) 2007 gps_logger_mg@tanundra.com. all rights reserved."

#define NULL (0)

typedef unsigned char boolean;

#define TRUE ((boolean) 1)
#define FALSE ((boolean) 0)

/*@-exportlocal@*/
/*@-exportheader@*/
#ifdef DEBUG
/*@-namechecks@*/ /*@noreturnwhenfalse@*/ static void __assert (/*@notnull@*/ const char* const filename, /*@notnull@*/ const unsigned int fileline, /*@notnull@*/ const char* const expression) __attribute__ ((noreturn)); /*@=namechecks@*/
#define assert(x) do { if (!(x)) __assert (__FILE__, (unsigned int) __LINE__, #x); } while (FALSE)
#else
/*@i@*/ #define assert(x)
#endif
/*@=exportheader@*/
/*@=exportlocal@*/

typedef boolean (*packlzari_output_handler_t) (const unsigned char* const, const unsigned int);

/* ----------------------------------------------------------------------------------------------------*/

/* Derived from LZARI - 4/7/1989 Haruhiko Okumura - EXTENSIVELY modified */

/* ----------------------------------------------------------------------------------------------------*/

#define N				256

#define F				96

#define T				2

#define NIL				N

#define M				15

#define Q1				(1UL << M)
#define Q2				(2 * Q1)
#define Q3				(3 * Q1)
#define Q4				(4 * Q1)
#define MAX_CUM			(Q1 - 1)

#define N_CHAR			(256 - T + F)

/* ----------------------------------------------------------------------------------------------------*/

typedef enum {
		state_decode_initial = 0,
		state_decode_char,
		state_decode_posn,
		state_decode_over
} state_decode_t;

typedef struct {
		state_decode_t decode_S;
		unsigned short decode_i, decode_r, decode_s, decode_c, decode_p;
		unsigned long value;
		unsigned char bitbuff, bitmask;
		/*@shared@*/ packlzari_output_handler_t output_handler;
		unsigned char buffer [N + F - 1];
		unsigned long lo, hi;
		unsigned short chr_to_sym [N_CHAR], sym_to_chr [N_CHAR + 1];
		unsigned short sym_cnt [N_CHAR + 1], sym_cum [N_CHAR + 1], pos_cum [N + 1];
} state_t;

typedef struct {
		/*@shared@*/ const unsigned char * buffer;
		unsigned short length, offset;
} input_t;

/* ----------------------------------------------------------------------------------------------------*/

static void model_init (/*@out@*/ state_t* const state)
{
		unsigned short i, sym;

		assert (state != NULL);

		state->sym_cum [N_CHAR] = 0;
		for (sym = (unsigned short) N_CHAR; sym >= (unsigned short) 1; sym--) {
				unsigned short ch = (unsigned short) (sym - 1);
				state->chr_to_sym [ch] = sym;
				state->sym_to_chr [sym] = ch;
				state->sym_cnt [sym] = (unsigned short) 1;
				state->sym_cum [sym - 1] = (unsigned short) (state->sym_cum [sym] + state->sym_cnt [sym]);
		}
		state->sym_cnt [0] = 0;
		state->pos_cum [N] = 0;
		for (i = (unsigned short) N; i >= (unsigned short) 1; i--)
				state->pos_cum [i - 1] = (unsigned short) (state->pos_cum [i] + 10000 / (i + 200));
		state->lo = 0;
		state->hi = Q4;
}

static void model_update (state_t* const state, const unsigned short sym)
{
		unsigned short i;

		assert (state != NULL);
		assert (sym < (unsigned short) (N_CHAR + 1));

		if (state->sym_cum [0] >= (unsigned short) MAX_CUM) {
				unsigned short c = 0;
				for (i = (unsigned short) N_CHAR; i > 0; i--) {
						state->sym_cum [i] = c;
						state->sym_cnt [i] = (unsigned short) ((unsigned short) (state->sym_cnt [i] + 1) >> 1);
						c += state->sym_cnt [i];
				}
				state->sym_cum [0] = c;
		}
		for (i = sym; state->sym_cnt [i] == state->sym_cnt [i - 1]; i--)
				/*@i@*/ ;
		if (i < sym) {
				unsigned short ch_i = state->sym_to_chr [i], ch_sym = state->sym_to_chr [sym];
				state->sym_to_chr [i] = ch_sym;
				state->sym_to_chr [sym] = ch_i;
				state->chr_to_sym [ch_i] = sym;
				state->chr_to_sym [ch_sym] = i;
		}
		state->sym_cnt [i]++;
		while (--i > 0)
				state->sym_cum [i]++;
		if (i == 0)
				state->sym_cum [i]++;
}

/* ----------------------------------------------------------------------------------------------------*/

static void arith_update (state_t* const state, const unsigned short* const cum, const unsigned short off)
{
		unsigned long range;

		assert (state != NULL);
		assert (cum != NULL);
		assert (state->hi >= state->lo);

		range = state->hi - state->lo;
		state->hi = state->lo + (range * cum [off]) / cum [0];
		state->lo = state->lo + (range * cum [off + 1]) / cum [0];
}

/* ----------------------------------------------------------------------------------------------------*/

/* ----------------------------------------------------------------------------------------------------*/

static unsigned char decode_b_get (state_t* const state, input_t* const input)
{
		assert (state != NULL);
		assert (input != NULL);
		assert (!(input->offset == input->length && (state->bitmask >> 1) == (unsigned char) 0));

		if ((state->bitmask >>= 1) == (unsigned char) 0) {
				state->bitbuff = input->buffer [input->offset++]; state->bitmask = (unsigned char) 0x80;
		}
		return (unsigned char) ((state->bitbuff & state->bitmask) != (unsigned char) 0	? 1 : 0);
}

static boolean decode_b_empty (state_t* const state, input_t* const input)
{
		assert (state != NULL);
		assert (input != NULL);

		return (input->offset == input->length && (state->bitmask >> 1) == (unsigned char) 0) ? TRUE : FALSE;
}

/* ----------------------------------------------------------------------------------------------------*/

static unsigned short decode_p_search (unsigned short* const t, const unsigned short n, const unsigned short x)
{
		unsigned short i = (unsigned short) 1, j = n, k;

		assert (t != NULL);

		while (i < j) {
				k = (unsigned short) ((i + j) >> 1);
				if (t[k] > x) {
						i = (unsigned short) (k + 1);
				} else {
						j = k;
				}
		}
		return i;
}

static boolean decode_p_init (/*@out@*/ state_t* const state)
{
		assert (state != NULL);

		state->bitbuff = (unsigned char) 0;
		state->bitmask = (unsigned char) 0;
		state->value = 0;
		model_init (state);
		return TRUE;
}

static boolean decode_p_pre (state_t* const state, input_t* const input, unsigned short* const offset)
{
		assert (state != NULL);
		assert (input != NULL);
		assert (offset != NULL);

		for (; *offset < (unsigned short) (M + 2); (*offset)++) {
				if (decode_b_empty (state, input) == TRUE)
						return TRUE;
				/*@i@*/ state->value = (state->value << 1) + (unsigned long) decode_b_get (state, input);
		}
		return FALSE;
}

static boolean decode_p_update (state_t* const state, input_t* const input)
{
		assert (state != NULL);
		assert (input != NULL);

		for ( ; ; ) {
				if (state->lo >= Q2) {
						if (decode_b_empty (state, input) == TRUE)
								return TRUE;
						state->value -= Q2;	 state->lo -= Q2;  state->hi -= Q2;
				} else if (state->lo >= Q1 && state->hi <= Q3) {
						if (decode_b_empty (state, input) == TRUE)
								return TRUE;
						state->value -= Q1;	 state->lo -= Q1;  state->hi -= Q1;
				} else if (state->hi > Q2) {
						break;
				} else {
						if (decode_b_empty (state, input) == TRUE)
								return TRUE;
						/*@i@*/ ;
				}
				state->lo += state->lo;	 state->hi += state->hi;
				state->value = (state->value << 1) + (unsigned long) decode_b_get (state, input);
		}
		return FALSE;
}

static void decode_p_chr_initial (state_t* const state)
{
		assert (state != NULL);

		state->decode_s = decode_p_search (state->sym_cum, (unsigned short) N_CHAR,
				(unsigned short) (((state->value - state->lo + 1) * state->sym_cum [0] - 1) / (state->hi - state->lo)));
		assert (state->decode_s < (unsigned short) sizeof (state->sym_to_chr));
		state->decode_c = state->sym_to_chr [state->decode_s];
		assert ((unsigned short) (state->decode_s - 1) < (unsigned short) sizeof (state->sym_cum));
		arith_update (state, state->sym_cum, (unsigned short) (state->decode_s - 1));
}

static boolean decode_p_chr_process (state_t* const state, input_t* const input)
{
		assert (state != NULL);
		assert (input != NULL);

		if (decode_p_update (state, input) == TRUE)
				return TRUE;
		model_update (state, state->decode_s);
		return FALSE;
}

static void decode_p_pos_initial (state_t* const state)
{
		assert (state != NULL);

		state->decode_p = decode_p_search (state->pos_cum, (unsigned short) N,
				(unsigned short) (((state->value - state->lo + 1) * state->pos_cum [0] - 1) / (state->hi - state->lo))) - (unsigned short) 1;
		assert (state->decode_p < (unsigned short) sizeof (state->pos_cum));
		arith_update (state, state->pos_cum, state->decode_p);
}

static boolean decode_p_pos_process (state_t* const state, input_t* const input)
{
		assert (state != NULL);
		assert (input != NULL);

		if (decode_p_update (state, input) == TRUE)
				return TRUE;
		return FALSE;
}

static boolean decode_p_term (state_t* const state)
{
		assert (state != NULL);

		/*@i@*/ (void) state;
		return TRUE;
}

/* ----------------------------------------------------------------------------------------------------*/

/* ----------------------------------------------------------------------------------------------------*/

static boolean decode_init (/*@out@*/ state_t* const state, packlzari_output_handler_t output_handler)
{
		state->output_handler = output_handler;
		if (decode_p_init (state) == FALSE)
				return FALSE;
		for (state->decode_r = 0; state->decode_r < (unsigned short) (N - F); state->decode_r++)
				state->buffer [state->decode_r] = ' ';
		state->decode_i = 0;
		state->decode_S = state_decode_initial;
		return TRUE;
}

static boolean decode_output_chr (state_t* const state, const unsigned char chr)
{
		if (state->output_handler (&chr, (unsigned int) 1) == FALSE)
				return FALSE;
		state->buffer [state->decode_r] = chr;
		if (state->decode_r++ == (unsigned short) (N - 1))
				state->decode_r = 0;
		return TRUE;
}

static boolean decode_output_pos (state_t* const state, const unsigned short chr, const unsigned short pos)
{
		unsigned short i, p = (unsigned short) ((unsigned short) (state->decode_r - pos - 1) & (N - 1)),
					   n = (unsigned short) (chr - 255 + T);
		for (i = 0; i < n; i++) {
				if (decode_output_chr (state, state->buffer [(p + i) & (N - 1)]) == FALSE)
						return FALSE;
		}
		return TRUE;
}

static boolean decode_process (state_t* const state, const unsigned char* const buffer, const unsigned short length)
{
		input_t input;
		input.buffer = buffer;
		input.length = length;
		input.offset = 0;

		while (state->decode_S != state_decode_over)
		{
				if (state->decode_S == state_decode_initial) {
						if (decode_p_pre (state, &input, &state->decode_i) == TRUE)
								break;
						decode_p_chr_initial (state);
						state->decode_S = state_decode_char;
				}
				if (state->decode_S == state_decode_char) {
						if (decode_p_chr_process (state, &input) == TRUE)
								break;
						if (state->decode_c < (unsigned short) 256) {
								if (decode_output_chr (state, (unsigned char) state->decode_c) == FALSE)
										return FALSE;
								decode_p_chr_initial (state);
								/* state->decode_S = state_decode_char; */
						} else if ((state->decode_c - 255 + T) < F) {
								decode_p_pos_initial (state);
								state->decode_S = state_decode_posn;
						} else {
								state->decode_S = state_decode_over;
						}
				}
				if (state->decode_S == state_decode_posn) {
						if (decode_p_pos_process (state, &input) == TRUE)
								break;
						if (decode_output_pos (state, state->decode_c, state->decode_p) == FALSE)
								return FALSE;
						decode_p_chr_initial (state);
						state->decode_S = state_decode_char;
				}
		}
		return TRUE;
}

static boolean decode_term (state_t* const state)
{
		const unsigned char deof = (unsigned char) 0xFF;
		if (state->decode_S != state_decode_initial) {
				/*@i@*/ while (state->decode_S != state_decode_over) {
						if (decode_process (state, &deof, (unsigned short) 1) == FALSE)
								return FALSE;
				}
		}
		if (decode_p_term (state) == FALSE)
				return FALSE;
		return TRUE;
}

/* ----------------------------------------------------------------------------------------------------*/

/* ----------------------------------------------------------------------------------------------------*/

/* ----------------------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

static unsigned long exec_count_read, exec_count_write;

static boolean exec_putx (const unsigned char* const buffer, const unsigned int length)
{
		unsigned int l = (unsigned int) write (fileno (stdout), buffer, (size_t) length);
		exec_count_write += (unsigned long) length;
		return (l == length) ? TRUE : FALSE;
}

static boolean exec (boolean (*init) (/*@out@*/ state_t* const, packlzari_output_handler_t),
				boolean (*proc) (state_t* const, const unsigned char* const, const unsigned short), boolean (*term) (state_t* const))
{
		unsigned char buffer [4096]; /* arbitrary */
		long length;

		state_t state;

		exec_count_read = exec_count_write = 0;
		if ((*init) (&state, exec_putx) == FALSE)
				return FALSE;
		while ((length = (long) read (fileno (stdin), buffer, sizeof (buffer))) > 0) {
				exec_count_read += (unsigned long) length;
				if ((*proc) (&state, buffer, (unsigned short) length) == FALSE)
						return FALSE;
		}
		if ((*term) (&state) == FALSE)
				return FALSE;
		(void) fprintf (stderr, "(%d/%d/%d; %d) :: ", N, F, T, (int) sizeof (state_t));
		(void) fprintf (stderr, "read = %lu bytes, write = %lu bytes :: ", exec_count_read, exec_count_write);
		(void) fprintf (stderr, "ratio = %f\n", (double) exec_count_write / exec_count_read);
		return TRUE;
}

#ifdef DEBUG
static void __assert (const char* const filename, const unsigned int fileline, const char* const expression)
{
		(void) fprintf (stderr, "assert(%s:%u): %s\n", filename, fileline, expression);
		exit (EXIT_FAILURE);
}
#endif

int main (int argc, char* argv [])
{
		/*@i@*/ (void) argc;
		/*@i@*/ (void) argv;

		fprintf (stderr, "gps_logger_mg v" VERSION ": lzari pack tool.\n");
		fprintf (stderr, COPYRIGHT "\n");

		return exec (decode_init, decode_process, decode_term) == TRUE ? EXIT_SUCCESS : EXIT_FAILURE;

}

/* ----------------------------------------------------------------------------------------------------*/

